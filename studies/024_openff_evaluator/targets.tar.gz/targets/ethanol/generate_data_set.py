from evaluator import unit
from evaluator.datasets import PhysicalPropertyDataSet, PropertyPhase, MeasurementSource
from evaluator.properties import Density, EnthalpyOfVaporization
from evaluator.substances import Substance
from evaluator.thermodynamics import ThermodynamicState


def add_property(
    property_type,
    data_set,
    smiles,
    temperature,
    value,
    phase,
    reference
):
    """A convenience function for adding properties to a data set.
    """

    substance = Substance.from_components(smiles)
    thermodynamic_state = ThermodynamicState(temperature, 101.325 * unit.kilopascal)

    source = MeasurementSource(reference=reference)

    physical_property = property_type(
        thermodynamic_state=thermodynamic_state,
        phase=PropertyPhase(phase),
        substance=substance,
        value=value,
        uncertainty=0.0 * value.units,
        source=source
    )

    data_set.add_properties(physical_property)


def main():
    """The main function which will generate the data set.
    """

    data_set = PhysicalPropertyDataSet()

    add_property(
        property_type=Density,
        data_set=data_set,
        smiles="CCO",
        temperature=298.15 * unit.kelvin,
        value=785.0 * unit.kilogram / unit.meter ** 3,
        phase=PropertyPhase.Liquid,
        reference=""
    )
    add_property(
        property_type=EnthalpyOfVaporization,
        data_set=data_set,
        smiles="CCO",
        temperature=298.15 * unit.kelvin,
        value=42.3 * unit.kilojoule / unit.mole,
        phase=PropertyPhase.Liquid | PropertyPhase.Gas,
        reference=""
    )

    add_property(
        property_type=Density,
        data_set=data_set,
        smiles="CCO",
        temperature=320.03 * unit.kelvin,
        value=766.0 * unit.kilogram / unit.meter ** 3,
        phase=PropertyPhase.Liquid,
        reference=""
    )
    add_property(
        property_type=EnthalpyOfVaporization,
        data_set=data_set,
        smiles="CCO",
        temperature=320.03 * unit.kelvin,
        value=41.0 * unit.kilojoule / unit.mole,
        phase=PropertyPhase.Liquid | PropertyPhase.Gas,
        reference=""
    )

    data_set.json("data_set.json", format=True)


if __name__ == '__main__':
    main()
