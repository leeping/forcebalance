from openff.evaluator import unit
from openff.evaluator.client import RequestOptions
from forcebalance.evaluator_io import Evaluator_SMIRNOFF


def main():

    # Create the options which evaluator should use.
    evaluator_options = RequestOptions()

    # Choose which calculation layers to make available.
    evaluator_options.calculation_layers = ["SimulationLayer"]

    # Create the force balance options
    target_options = Evaluator_SMIRNOFF.OptionsFile()
    target_options.estimation_options = evaluator_options

    # Set the path to the data set
    target_options.data_set_path = "data_set.json"

    # Set the property weights and denominators.
    density_denominator = 30.0 * unit.kilogram / unit.meter ** 3
    h_vap_denominator = 3.0 * unit.kilojoule / unit.mole

    target_options.weights = {
        "Density": 1.0,
        "EnthalpyOfVaporization": 1.0
    }
    target_options.denominators = {
        "Density": density_denominator,
        "EnthalpyOfVaporization": h_vap_denominator
    }

    # Save the options to file.
    with open("options.json", "w") as file:
        file.write(target_options.to_json())


if __name__ == "__main__":
    main()
