"""Computes the electrostatic potential (ESP) and electric field of methane and stores
it in a data store ready for use in an optimization."""
from openff.recharge.conformers import ConformerGenerator, ConformerSettings
from openff.recharge.esp import ESPSettings
from openff.recharge.esp.psi4 import Psi4ESPGenerator
from openff.recharge.esp.storage import MoleculeESPRecord, MoleculeESPStore
from openff.recharge.grids import GridSettings
from openff.recharge.utilities.molecule import smiles_to_molecule


def main():

    # Create a compact store for the computes ESP values.
    esp_store = MoleculeESPStore()

    # Define the settings to generate the ESP using.
    esp_settings = ESPSettings(
        method="hf",
        basis="6-31G*",
        grid_settings=GridSettings(
            type="fcc", spacing=0.7, inner_vdw_scale=1.4, outer_vdw_scale=2.0
        )
    )

    # Compute the ESP of methane.
    molecule = smiles_to_molecule("C")

    conformers = ConformerGenerator.generate(
        molecule, ConformerSettings(sampling_mode="sparse", max_conformers=1)
    )

    _, grid_coordinates, esp, electric_field = Psi4ESPGenerator.generate(
        molecule, conformers[0], esp_settings
    )

    # Store the ESP for use in the optimization.
    esp_store.store(
        MoleculeESPRecord.from_molecule(
            molecule,
            conformers[0],
            grid_coordinates,
            esp,
            electric_field,
            esp_settings
        )
    )


if __name__ == "__main__":
    main()
