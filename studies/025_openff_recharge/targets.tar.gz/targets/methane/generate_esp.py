"""Computes the electrostatic potential (ESP) of methane and stores it
in a data store ready for use in an optimization."""
from openff.recharge.conformers import ConformerGenerator, ConformerSettings
from openff.recharge.esp import ESPSettings
from openff.recharge.esp.psi4 import Psi4ESPGenerator
from openff.recharge.esp.storage import MoleculeESPRecord, MoleculeESPStore
from openff.recharge.grids import GridSettings
from openff.recharge.utilities.openeye import smiles_to_molecule


def main():

    # Create a compact store for the computes ESP values.
    esp_store = MoleculeESPStore()

    # Define the settings to generate the ESP using.
    esp_settings = ESPSettings(
        method="hf",
        basis="6-31G*",
        grid_settings=GridSettings(
            type="fcc", spacing=0.7, inner_vdw_scale=1.4, outer_vdw_scale=2.0
        )
    )

    # Compute the ESP of methane.
    oe_molecule = smiles_to_molecule("C")

    conformers = ConformerGenerator.generate(
        oe_molecule, ConformerSettings(sampling_mode="sparse", max_conformers=1)
    )

    grid_coordinates, esp = Psi4ESPGenerator.generate(
        oe_molecule, conformers[0], esp_settings
    )

    # Store the ESP for use in the optimization.
    esp_store.store(
        MoleculeESPRecord.from_oe_molecule(
            oe_molecule, conformers[0], grid_coordinates, esp, esp_settings
        )
    )


if __name__ == "__main__":
    main()
