import json

from forcebalance.property_estimator_io import PropertyEstimate_SMIRNOFF
from propertyestimator import unit
from propertyestimator.client import PropertyEstimatorOptions
from propertyestimator.datasets import PhysicalPropertyDataSet
from propertyestimator.properties import Density, EnthalpyOfVaporization, MeasurementSource, PropertyPhase
from propertyestimator.substances import Substance
from propertyestimator.thermodynamics import ThermodynamicState
from propertyestimator.utils.serialization import TypedJSONEncoder
from propertyestimator.workflow import WorkflowOptions


def create_data_set():

    # Create a substance with equal mole fractions of each component
    substance = Substance.from_components('BrBr')

    # Define the thermodynamic state at which the property was measured.
    thermodynamic_state = ThermodynamicState(temperature=298.15 * unit.kelvin,
                                             pressure=1 * unit.atmosphere)

    # Define the provenance of this measurement
    source = MeasurementSource(reference='CRC Handbook of Chemistry and Physics, 84th Edition (via Wikipedia).')

    # Create a density measurement (the uncertainty is the last decimal point)
    measurement_rho = Density(thermodynamic_state=thermodynamic_state,
                              phase=PropertyPhase.Liquid,
                              substance=substance,
                              value=3102.8 * unit.kilogram / unit.meter ** 3,
                              uncertainty=0.1 * unit.kilogram / unit.meter ** 3,
                              source=source)

    # Create a density measurement (the uncertainty is the last decimal point)
    measurement_hvap = EnthalpyOfVaporization(thermodynamic_state=thermodynamic_state,
                                              phase=PropertyPhase.Liquid,
                                              substance=substance,
                                              value=29.96 * unit.kilojoule / unit.mole,
                                              uncertainty=0.01 * unit.kilojoule / unit.mole,
                                              source=source)

    # Add the measurement to a data set
    data_set = PhysicalPropertyDataSet()
    data_set.properties[substance.identifier] = [measurement_rho, measurement_hvap]

    # Save the data set to file.
    with open('data_set.json', 'w') as file:
        json.dump(data_set, file, sort_keys=True, indent=4, separators=(',', ': '), cls=TypedJSONEncoder)


def create_density_workflow_schema(workflow_options):

    # Modify the default density workflow to use less
    # molecules, a larger timestep, less steps per iteration.
    default_schema = Density.get_default_simulation_workflow_schema(workflow_options)
    group_schema = default_schema.protocols['conditional_group']

    # Reduce the number of molecules to 100
    coordinates_schema = default_schema.protocols['build_coordinates']
    coordinates_schema.inputs['.max_molecules'] = 100

    # Fix a charging exception.
    assign_parameters_schema = default_schema.protocols['assign_parameters']
    assign_parameters_schema.inputs['.apply_known_charges'] = False

    # Reduce the simulation lengths / increase the timestep.
    equilibration_schema = default_schema.protocols['equilibration_simulation']
    equilibration_schema.inputs['.steps_per_iteration'] = 50000
    equilibration_schema.inputs['.output_frequency'] = 500
    equilibration_schema.inputs['.timestep'] = 8.0 * unit.femtosecond
    production_schema = next(x for x in group_schema.grouped_protocol_schemas if x.id == 'production_simulation')
    production_schema.inputs['.steps_per_iteration'] = 25000
    production_schema.inputs['.output_frequency'] = 500
    production_schema.inputs['.timestep'] = 8.0 * unit.femtosecond

    return default_schema


def create_h_vap_workflow_schema(workflow_options):

    # Modify the default density workflow to use less
    # molecules, a larger timestep, less steps per iteration.
    default_schema = EnthalpyOfVaporization.get_default_simulation_workflow_schema(workflow_options)

    grouped_schemas = default_schema.protocols['converge_uncertainty'].grouped_protocol_schemas

    # Reduce the number of molecules to 100
    coordinates_schema = default_schema.protocols['build_coordinates_liquid']
    coordinates_schema.inputs['.max_molecules'] = 100
    extract_enthalpy_schema = next(x for x in grouped_schemas if x.id == 'extract_liquid_energy')
    extract_enthalpy_schema.inputs['.divisor'] = 100
    scale_gradients_schema = default_schema.protocols['scale_liquid_gradient_$(repl)']
    scale_gradients_schema.inputs['.divisor'] = 100

    # Fix a charging exception.
    assign_parameters_schema = default_schema.protocols['assign_parameters_liquid']
    assign_parameters_schema.inputs['.apply_known_charges'] = False
    assign_parameters_schema = default_schema.protocols['assign_parameters_gas']
    assign_parameters_schema.inputs['.apply_known_charges'] = False

    # Reduce the simulation lengths / increase the timestep.
    equilibration_schema = default_schema.protocols['equilibration_simulation_liquid']
    equilibration_schema.inputs['.steps_per_iteration'] = 50000
    equilibration_schema.inputs['.output_frequency'] = 500
    equilibration_schema.inputs['.timestep'] = 8.0 * unit.femtosecond
    production_schema = next(x for x in grouped_schemas if x.id == 'production_simulation_liquid')
    production_schema.inputs['.steps_per_iteration'] = 25000
    production_schema.inputs['.output_frequency'] = 500
    production_schema.inputs['.timestep'] = 8.0 * unit.femtosecond

    equilibration_schema = default_schema.protocols['equilibration_simulation_gas']
    equilibration_schema.inputs['.steps_per_iteration'] = 50000
    equilibration_schema.inputs['.output_frequency'] = 1000
    equilibration_schema.inputs['.timestep'] = 8.0 * unit.femtosecond
    production_schema = next(x for x in grouped_schemas if x.id == 'production_simulation_gas')
    production_schema.inputs['.steps_per_iteration'] = 100000
    production_schema.inputs['.output_frequency'] = 1000
    production_schema.inputs['.timestep'] = 8.0 * unit.femtosecond

    return default_schema


def create_options_file():

    # Create the options which propertyestimator should use.
    estimator_options = PropertyEstimatorOptions()

    # Only use simulations for now
    estimator_options.allowed_calculation_layers = ['SimulationLayer']

    # Specify we don't want to estimate properties to within
    # a given uncertainty.
    workflow_options = WorkflowOptions(convergence_mode=WorkflowOptions.ConvergenceMode.NoChecks)

    estimator_options.workflow_options = {
        'Density': {'SimulationLayer': workflow_options},
        'EnthalpyOfVaporization': {'SimulationLayer': workflow_options}
    }

    # Override the default workflow settings.
    density_schema = create_density_workflow_schema(workflow_options)
    h_vap_schema = create_h_vap_workflow_schema(workflow_options)

    estimator_options.workflow_schemas = {
        'Density': {'SimulationLayer': density_schema},
        'EnthalpyOfVaporization': {'SimulationLayer': h_vap_schema}
    }

    # Create the force balance options
    target_options = PropertyEstimate_SMIRNOFF.OptionsFile()
    target_options.estimation_options = estimator_options

    # Set the path to the data set
    target_options.data_set_path = 'data_set.json'

    # Set the property weights and denominators.
    target_options.weights = {
        "Density": 1.0,
        "EnthalpyOfVaporization": 1.0
    }
    target_options.denominators = {
        "Density": 10.0,
        "EnthalpyOfVaporization": 0.3
    }

    # Save the options to file.
    with open('options.json', 'w') as file:
        file.write(target_options.to_json())


def main():
    create_data_set()
    create_options_file()


if __name__ == '__main__':
    main()
