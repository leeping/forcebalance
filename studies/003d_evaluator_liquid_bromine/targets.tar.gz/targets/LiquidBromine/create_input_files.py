from forcebalance.evaluator import Evaluator_SMIRNOFF

from evaluator import unit
from evaluator.client import RequestOptions
from evaluator.datasets import MeasurementSource, PhysicalPropertyDataSet, PropertyPhase
from evaluator.properties import Density, EnthalpyOfVaporization
from evaluator.substances import Substance
from evaluator.thermodynamics import ThermodynamicState


def create_data_set():

    # Create a substance with equal mole fractions of each component
    substance = Substance.from_components("BrBr")

    # Define the thermodynamic state at which the property was measured.
    thermodynamic_state = ThermodynamicState(
        temperature=298.15 * unit.kelvin, pressure=1 * unit.atmosphere
    )

    # Define the provenance of this measurement
    source = MeasurementSource(
        reference="CRC Handbook of Chemistry and Physics, 84th Edition (via Wikipedia)."
    )

    # Create a density measurement (the uncertainty is the last decimal point)
    measurement_rho = Density(
        thermodynamic_state=thermodynamic_state,
        phase=PropertyPhase.Liquid,
        substance=substance,
        value=3102.8 * unit.kilogram / unit.meter ** 3,
        uncertainty=0.1 * unit.kilogram / unit.meter ** 3,
        source=source,
    )

    # Create a density measurement (the uncertainty is the last decimal point)
    measurement_hvap = EnthalpyOfVaporization(
        thermodynamic_state=thermodynamic_state,
        phase=PropertyPhase.Liquid,
        substance=substance,
        value=29.96 * unit.kilojoule / unit.mole,
        uncertainty=0.01 * unit.kilojoule / unit.mole,
        source=source,
    )

    # Add the measurement to a data set
    data_set = PhysicalPropertyDataSet()
    data_set.add_properties(measurement_rho, measurement_hvap)

    # Save the data set to file.
    data_set.json("data_set.json", format=True)


def create_density_workflow_schema():

    # Modify the default density workflow to use less
    # molecules, a larger timestep, less steps per iteration.
    calculation_schema = Density.default_simulation_schema(n_molecules=100)
    default_schema = calculation_schema.workflow_schema
    default_schema.replace_protocol_types({
        "BaseBuildSystem": "BuildSmirnoffSystem"
    })

    schemas_by_id = {x.id: x for x in default_schema.protocol_schemas}
    group_schema = schemas_by_id["conditional_group"]

    # Fix a charging exception.
    assign_parameters_schema = schemas_by_id["assign_parameters"]
    assign_parameters_schema.inputs[".apply_known_charges"] = False

    # Reduce the simulation lengths / increase the timestep.
    equilibration_schema = schemas_by_id["equilibration_simulation"]
    equilibration_schema.inputs[".steps_per_iteration"] = 50000
    equilibration_schema.inputs[".output_frequency"] = 500
    equilibration_schema.inputs[".timestep"] = 8.0 * unit.femtosecond
    production_schema = group_schema.protocol_schemas["production_simulation"]
    production_schema.inputs[".steps_per_iteration"] = 25000
    production_schema.inputs[".output_frequency"] = 500
    production_schema.inputs[".timestep"] = 8.0 * unit.femtosecond

    return calculation_schema


def create_h_vap_workflow_schema():

    # Modify the default density workflow to use less
    # molecules, a larger timestep, less steps per iteration.
    calculation_schema = EnthalpyOfVaporization.default_simulation_schema(n_molecules=100)
    default_schema = calculation_schema.workflow_schema
    default_schema.replace_protocol_types({
        "BaseBuildSystem": "BuildSmirnoffSystem"
    })

    schemas_by_id = {x.id: x for x in default_schema.protocol_schemas}
    group_schema = schemas_by_id["converge_uncertainty"]

    # Fix a charging exception.
    assign_parameters_schema = schemas_by_id["assign_parameters_liquid"]
    assign_parameters_schema.inputs[".apply_known_charges"] = False
    assign_parameters_schema = schemas_by_id["assign_parameters_gas"]
    assign_parameters_schema.inputs[".apply_known_charges"] = False

    # Reduce the simulation lengths / increase the timestep.
    equilibration_schema = schemas_by_id["equilibration_simulation_liquid"]
    equilibration_schema.inputs[".steps_per_iteration"] = 50000
    equilibration_schema.inputs[".output_frequency"] = 500
    equilibration_schema.inputs[".timestep"] = 8.0 * unit.femtosecond
    production_schema = group_schema.protocol_schemas[
        "production_simulation_liquid"
    ]
    production_schema.inputs[".steps_per_iteration"] = 25000
    production_schema.inputs[".output_frequency"] = 500
    production_schema.inputs[".timestep"] = 8.0 * unit.femtosecond

    equilibration_schema = schemas_by_id["equilibration_simulation_gas"]
    equilibration_schema.inputs[".steps_per_iteration"] = 50000
    equilibration_schema.inputs[".output_frequency"] = 1000
    equilibration_schema.inputs[".timestep"] = 8.0 * unit.femtosecond
    production_schema = group_schema.protocol_schemas[
        "production_simulation_gas"
    ]
    production_schema.inputs[".steps_per_iteration"] = 100000
    production_schema.inputs[".output_frequency"] = 1000
    production_schema.inputs[".timestep"] = 8.0 * unit.femtosecond

    return calculation_schema


def create_options_file():

    # Create the options which evaluator should use.
    request_options = RequestOptions()

    # Only use simulations for now
    request_options.allowed_calculation_layers = ["SimulationLayer"]

    # Override the default workflow settings.
    density_schema = create_density_workflow_schema()
    h_vap_schema = create_h_vap_workflow_schema()

    request_options.add_schema("SimulationLayer", "Density", density_schema)
    request_options.add_schema(
        "SimulationLayer", "EnthalpyOfVaporization", h_vap_schema
    )

    # Create the force balance options
    target_options = Evaluator_SMIRNOFF.OptionsFile()
    target_options.estimation_options = request_options

    # Set the path to the data set
    target_options.data_set_path = "data_set.json"

    # Set the property weights and denominators.
    target_options.weights = {"Density": 1.0, "EnthalpyOfVaporization": 1.0}
    target_options.denominators = {
        "Density": 10.0 * unit.kilogram / unit.meter ** 3,
        "EnthalpyOfVaporization": 0.3 * unit.kilojoules / unit.mole
    }

    # Save the options to file.
    with open("options.json", "w") as file:
        file.write(target_options.to_json())


def main():
    create_data_set()
    create_options_file()


if __name__ == "__main__":
    main()
